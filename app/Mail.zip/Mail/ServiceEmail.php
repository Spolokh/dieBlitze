<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailables\{
    Content,
    Address,
    Envelope
};

class ServiceEmail extends Mailable // implements ShouldQueue
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(public array $data)
    {
        //
    }

    /**
     * Get the message envelope.
     *
     * @return \Illuminate\Mail\Mailables\Envelope
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: $this->data['subject'],
            replyTo: [
                new Address($this->data['mail'], $this->data['name']),
            ],    
        );
    }

    /**
     * Get the message content definition.
     *
     * @return \Illuminate\Mail\Mailables\Content
     */
    public function content(): Content
    {
        return new Content(
            view: 'mails.contact',
            with: [
                'ip'       => $this->data['ip'],
                'name'     => $this->data['name'],
                'mail'     => $this->data['mail'],
                'phone'    => $this->data['phone'],
                'subject'  => $this->data['subject'],
                'mailbody' => $this->data['message'],
            ],
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array
     */
    public function attachments(): array
    {
        return [];
    }

    protected function getReplyTo(): string
    {
        return $this->data['name'] ?? 'Пользователь сайта';
    }
}
