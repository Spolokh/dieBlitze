<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;

use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Address;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Mail\Mailables\Attachment;

use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class UserRegistered extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     */
    public function __construct(public User $user) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Добро пожаловать!',
            replyTo: [
                new Address('support@site.ru', 'Поддержка')
            ],
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'mails.registered',
            with: [
                'user' => $this->user
            ],
        );
    }

    public function attachments(): array
    {
        return [];
    }
}
